package com.example.widget_inkwell

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
