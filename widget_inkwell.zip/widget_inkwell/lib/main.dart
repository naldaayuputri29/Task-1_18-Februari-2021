import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: MyHomePage()));
}

class MyHomePage extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Inkwell"),
      ),
      body: Padding(
        padding: EdgeInsets.all(8.0),
        child: InkWell(
          onTap: (){
            print("Ditekan");
          },
          child: Container(
            width: 100.0,
            height: 100.0,
            color: Colors.lightGreen,
          ),
        ),
      ),
    );
  }
}

