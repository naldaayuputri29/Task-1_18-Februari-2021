package com.example.widget_textformfield

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
