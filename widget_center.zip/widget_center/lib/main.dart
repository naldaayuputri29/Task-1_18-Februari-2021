import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: MyHomePage()));
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Center"),
        ),
        body : Center(
          child: Text("Assalamua'alaikum Warahmatullahi Wabarakatuh", style: TextStyle(
              fontSize: 30.0,
              fontWeight: FontWeight.bold),
          ),
        )
    );
  } }