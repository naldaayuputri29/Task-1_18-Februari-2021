package com.example.widget_text

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
