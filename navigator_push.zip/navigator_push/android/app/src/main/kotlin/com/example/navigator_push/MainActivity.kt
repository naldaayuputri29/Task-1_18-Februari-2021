package com.example.navigator_push

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
