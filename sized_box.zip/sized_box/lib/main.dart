import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: MyHomePage()));
}

class MyHomePage extends StatelessWidget{
  @override
  Widget build(BuildContext){
    return Scaffold(
      appBar: AppBar(
        title: Text("SizedBox"),
      ),
      body: Column(
        children: <Widget>[
          Text("Allahu Akbar", style: TextStyle(fontSize: 30.0),),
          SizedBox(height: 20.0,),
          Text("Masyallah", style: TextStyle(fontSize: 30.0),)

        ],
      ),
    );
  }
}
