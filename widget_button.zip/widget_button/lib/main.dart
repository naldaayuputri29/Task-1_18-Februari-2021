import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: MyHomePage()));
}

class MyHomePage extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return Scaffold(
     appBar: AppBar(
       title: Text("Buttons"),
     ),
      body: Column(
        children: <Widget>[
          RaisedButton(
            color: Colors.amber,
            child: Text("Raised Button"),
            onPressed: () {},
          ),
          SizedBox(height: 10,),
          MaterialButton(
            color: Colors.lime,
            child: Text("Material Button"),
            onPressed: () {},
          ),
          SizedBox(height: 10,),
          // ignore: deprecated_member_use
          FlatButton(
            color: Colors.lightGreenAccent,
            child: Text("FlatButton Button"),
            onPressed: () {},
          ),
        ],
    ),
    );
  }
}

