package com.example.widget_button

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
