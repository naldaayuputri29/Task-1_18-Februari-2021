import 'package:flutter/material.dart';

void main(){
  runApp(MaterialApp(home: MyHomePage()));
}

class MyHomePage extends StatelessWidget{
  @override
  Widget build(BuildContext){
    return Scaffold(
      appBar: AppBar(
        title: Text("Icon"),
      ),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Column(
              children: <Widget>[
                Icon(Icons.access_alarm),
                Text('Alarm')
              ],
            ),

        Column(
          children: <Widget>[
                    Icon(Icons.phone),
                    Text('Phone')
          ],
        ),
            
          Column(
            children: <Widget>[
                    Icon(Icons.book)
            ],
          )    
          ],
        ),
      ),
    );
  }

}